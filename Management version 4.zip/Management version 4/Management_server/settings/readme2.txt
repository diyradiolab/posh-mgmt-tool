$name in $names = each $name is a columnname = latencytest, raidstatus

$client in $clientenumerator = this is a single client pulled from the collate.xml file that holds all clients. Collate.xml is imported into a hashtable called $ClientList

The individual data elements for each client are referenced by this psuedocode: 

foreach ($client in $clientenumerator)
	foreach ($name in $names) 
		GetAndDisplay $client.value.$name.columnname