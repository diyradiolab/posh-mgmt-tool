﻿################################################################################# 
## 
## Server Health Check 
## Created by Sravan Kumar S  
## Date : 3 Mar 2014 
## Version : 1.0 
## Email: sravankumar.s@outlook.com   
## This scripts check the server Avrg CPU and Memory utlization along with C drive 
## disk utilization and sends an email to the receipents included in the script
################################################################################ 

[array]$ServerList = "localhost"
$outputfolder = "C:\Users\administrator\Dropbox\scripts\management_client\output"

$Result = @() 
ForEach($computername in $ServerList) 
{

$AVGProc = Get-WmiObject -computername $computername win32_processor | 
Measure-Object -property LoadPercentage -Average | Select Average
$OS = gwmi -Class win32_operatingsystem -computername $computername |
Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}
$vol = Get-WmiObject -Class win32_Volume -ComputerName $computername -Filter "DriveLetter = 'C:'" |
Select-object @{Name = "C PercentFree"; Expression = {“{0:N2}” -f  (($_.FreeSpace / $_.Capacity)*100) } }
$volfree = Get-WmiObject -Class win32_Volume -ComputerName $computername -Filter "DriveLetter = 'C:'" |
Select-object @{Name = "C Free Space"; Expression = {“{0:N2}” -f  ($_.FreeSpace/1gb) } }
  
$result = [PSCustomObject] @{  #overwrites the hash table each time
      
        CPULoad = "$($AVGProc.Average)"
        MemLoad = "$($OS.MemoryUsage)"
        CDrive = "$($vol.'C PercentFree')"
        CDrivefree = "$($volfree.'c free space')"
    }
    $result.memload |out-file $outputfolder\memoryload.txt
    $result.CPULoad |out-file $outputfolder\cpuaverage.txt
    $result.CDrive |out-file $outputfolder\cdrivepercentage.txt
    $result.Cdrivefree |out-file $outputfolder\cdrivefree.txt
    }
   
   
