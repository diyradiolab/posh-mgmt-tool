ToDo:
Make cell height fixed
make cell width max out
make webpage to input the variables you want for main.ps1 in case you want to change them.
copy file from client to server via command line - watch win scp youtube


The order must match in columnheadinglist.txt and columnlist.txt
columnlist.txt is cycled through for each client to get each of those values

##############
Code to get all XML files, import as has table, then cycle through each file: 
remember to use $($client.clientid) if referencing in a string or somewhere it's necessary.

       $entries = Get-ChildItem -Recurse $WebsiteHome\clients "*.xml"
           
     
          foreach($entry in $entries){

          $client = Import-Clixml $entry.FullName

          $client.clientid
        
        
            }
##############

Files
CollateAllClientsToSingleXML.ps1 goes through all XML files makes a hash table of each XML file, then makes a hash table of those hash tables.
-this makes export to HTML easier

CollateToHTML.ps1 - create HTML document C:\inetpub\wwwroot\Management\reports\collatetohtml_output.html which shows
-all clients alphabetically and highlights the offline ones in Yellow using the get-ahcomputeroffline.ps1 function

Get-AhComputerOffline.ps1 - Function used to determine if a computer is offline
Input - file
Output - $true or $false / (Offline or Online) - [when comparing use -eq not =]

Get-FileTimeLastAccessed.ps1 - Function used to determine the last time a file was accessed
input - file
Output - Get-Date.datetime (e.g. Sunday, June 25, 2017 10:33:51 AM)

Main.ps1 - used to set program variables, email variables, and call scripts that need to be run.

NewClientHTML.ps1 - this outputs to wwwroot...\newclientHTML.html and is a webpage that implementors of this whole program can go to 
-so when they are adding clients they can easily see the client number to use, since each client must have a unique number, but each client can have
-mulitple computers as long as they have unique computer names.

OfflineComputersAction.ps1 - this goes through all computers and sends an email if one is determined to be offline.

Send-ahEmailMessage.ps1 - small send email function that relies on the variables set in main.ps1 and the parameters passed to it, as in OfflineComputersAction.ps1

