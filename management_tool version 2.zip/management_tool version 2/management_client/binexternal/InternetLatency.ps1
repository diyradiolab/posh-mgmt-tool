[string]$OutputFile = "$OutputFolder\latencytest.txt"
[string]$TempOutputFile = "$OutputFolder\temporaryfile.txt"

$DestinationList = Get-content "$SettingsFolder\InternetLatency.txt" #list of hosts to test via ICMP

[int]$TotalResponse = 0 #is added regardless
[int]$Count = 0

foreach($Destination in $DestinationList){
   
        [int]$response = 0
        $time = (Test-Connection -ComputerName $Destination -Count 1  | Measure-Object -Property responsetime -Average).average
        write-host $Destination
        $response = ($time -as [int])
        $TotalResponse +=$response
        
            if($response){ #is only incremented if response is received
                $count ++ 
             }
              
}

    
$TotalResponse
$count
$TotalAverage = ($TotalResponse / $count)
$TotalAverage | out-file $OutputFile

#remove blank carriage returns by building a new file where  only lines that contain words are returned
remove-ahblanklines -inputfile $outputfile -temporaryfile $TempOutputFile