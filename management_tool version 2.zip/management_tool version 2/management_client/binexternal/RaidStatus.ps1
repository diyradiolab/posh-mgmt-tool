#this is sample script to demo how this works - simple.

$txt = "Raid is OK"


$txt | out-file $OutputFolder\raidstatus.txt