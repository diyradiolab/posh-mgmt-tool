﻿


[string]$OutputFile = "$OutputFolder\lastbootuptime.txt"
[string]$TempOutputFile = "$OutputFolder\temporaryfile.txt"

#get some properties of the computer, including the lastbootuptime
$lastboottime = Get-CimInstance -ClassName win32_operatingsystem

# write the last boot up time to a file called $outputfile
$lastboottime.LastBootUpTime |out-file $OutputFile

#remove blank carriage returns by building a new file where  only lines that contain words are returned
remove-ahblanklines -inputfile $outputfile -temporaryfile $TempOutputFile


