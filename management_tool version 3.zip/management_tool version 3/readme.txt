Enhancements

Planned Enhancements: 


version 3:
HTML output: added column to columns.csv to specify column width in pixels. adding new columns you can enter a value, or just ",," and it will default to 300 pixels wide.

HTML output: Padded table cells with 10 pixels to make more readable
Added the Last Updated datetime in italics below the computer name in the html output report.

Added CSS overflow:hidden in style.css on cell classes to prevent text from overflowing into adjacent cells

forgot to mention that in version 2 I added a new script on the client that reports c drive free space, ram, cpu.

version 2:
Previous functionality only showed Offline by highlighting yellow.

Added functionality highlights individual cells a different color. The color can be modified in the style.css file in wwwroot in the td.offline class.

Instead of using the columnheading and columnname text files to define new fields, that is now done in columns.csv in management_server\settings\ folder.

Thresholds parameters which determine the point at which the cells will be marked as having exceeded or not met the threshold are defined in the columnthreshold column, which holds values, and the columncompare column which determines if the threshold is above or below the value.

Valid values for columncompare are:
less - will trigger the threshold alert when the reported value is less than the value defined in columns.csv in columnthreshold
greater - will trigger the threshold alert when the reported value is greater than the value defined in columns.csv in columnthreshold
equal - will trigger the threshold alert when the reported value is not equal to the value defined in columns.csv in columnthreshold